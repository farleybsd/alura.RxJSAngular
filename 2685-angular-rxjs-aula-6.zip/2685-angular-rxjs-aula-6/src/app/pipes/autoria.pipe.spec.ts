import { AutoriaPipe } from './autoria.pipe';

describe('AutoriaPipe', () => {
  it('create an instance', () => {
    const pipe = new AutoriaPipe();
    expect(pipe).toBeTruthy();
  });
});
